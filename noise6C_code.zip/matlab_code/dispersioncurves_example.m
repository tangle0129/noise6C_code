% Author: Le Tang  
% Southern University of Science and Technology, China. 2021-11-05
% Email:tangle0129@gmail.com

%% Theoretical dispersion curves
% example


% input:
%             cvp: P wave's velocity model (m/s)
%             cvs: S wave's velocity model (m/s)
%             dns: density of model (kg/m^3)
%             thk: the depth of each layer (m)
%              pn: the interval of scanning frequency (Hz)
%              bn: the interval of scanning velocity (m/s)
%           f_min: start frequency (Hz)
%           f_max: end frequency (Hz)
%       lr_symbol: 1=Rayleigh; 2=Love
%          Norder: chose the order of calculation dispersion curves (include:0->Noder)
% output:
%         figure:dispersion points  
clear all;
close all;


cvp=[0.4,0.8]*1d3;
cvs=[0.15,0.85]*1d3;
dns=[1.9,2.5]*1e3;
thk=[1.4];
n=max(size(cvs));
pn=6;                       
bn=1;                       
Norder=1;                   
f_min=1;
f_max=150;
lr_symbol=1;

cd ./code
[f,pha]=ray_love_theory(cvp,cvs,dns,thk,pn,bn,Norder,f_min,f_max,lr_symbol);


figure('color','wh')
plot(f,pha,'ro');


%% arithmatic average inversion method 
%  input
%           symbol:1=Rayleigh ;2=Love
%        data(r,f):frequency profile(2 dim)
%                f:frequency(Hz)(lowest->highest)
%               nr:the numbers of traces
%
%  output
%
%          dep(r,d):depth for each frequency (2 dim)
%          dis(r,v):velocity for each depth (2 dim)
nr=1;
symbol=1;
cd ../
[Rdepth,Rdis]=arithmatic_inversion(symbol,pha,nr,f);

%% figure 
figure('color','wh')
plot(Rdis,Rdepth,'ro');



