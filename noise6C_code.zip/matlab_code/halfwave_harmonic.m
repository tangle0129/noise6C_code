function [dep,dep_v]=halfwave_harmonic(f,v,ratio)
%% harmonic average method for fundamental mode dispersion curve 
% modified half-wavelength method by Tang Le (2020 11.25. Sustech)

% input     f: frequency(HZ) low->high
%           v: phase velocity (m/s) corresponding to frequency
%           ratio : V(Rayleigh=0.92/Love=0.98) to VS ratio

v=v(end:-1:1)/ratio;
f=f(end:-1:1);
% velocity of each layer
dep_v=zeros(length(f),1);
% thick of each layer
dep=zeros(length(f),1);


dep(1)=v(1)/(2*f(1));
dep_v(1)=v(1);
 for i=2:length(f)
    dep(i)=v(i)/(2*f(i))-sum(dep(1:i-1));
    dep_v(i)=dep(i)/(1/(2*f(i))-sum(dep(1:i-1)./dep_v(1:i-1)));
end


end