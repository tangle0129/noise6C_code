% modified half-wavlength method by Tang Le
% Author: Le Tang  
% Southern University of Science and Technology, China. 2021-11-05
% Email:tangle0129@gmail.com 

% example

clear all;clc;close all;

load('./c_inv1.mat');

nr=13; % number of trace

fmin0=20;
fmax0=220;
f_0=round(fmin0/df);
f_1=round(fmax0/df);
f=fp(f_0:f_1);

data=c(1:nr,f_0:f_1);

% smooth for each dispersion curve
for i=1:nr
temp=smooth(data(i,:),0.6,'moving');
data(i,:)=temp;
end


% figure('color','wh')
% hold on
% for i=1:nr
%  plot(f,data(i,:),'*-')
% end
% axis([10 220  100 400])
% xlabel('Frequency(HZ)','fontsize',25);
% ylabel('Phase velocity(m/s)','fontsize',25);
% set(gca,'fontsize',25 ,'FontWeight','normal');
% box on;
% grid on;

% select the sutitable frequency arange
fmin=21-fmin0;
fmax=170-fmin0;
f_0=round(fmin/df);
f_1=round(fmax/df);
f1=f(f_0:f_1);

data1=data(1:nr,f_0:f_1);

% smooth for the whole frequency profile
[t1,t2]=size(data1);
data1=smooth(data1,0.002,'moving');
data1=reshape(data1,t1,t2);


%  figure('color','wh')
%  hold on
% for i=1:nr
%  plot(f1,data1(i,:),'*-')
% end
% axis([10 140  100 400])
% xlabel('Frequency(HZ)','fontsize',25);
% ylabel('Phase velocity(m/s)','fontsize',25);
% set(gca,'fontsize',25 ,'FontWeight','normal');
% box on;
% grid on;



%% plot the frequency profile
r0=[nr-1:-1:0]*0.5;
f0=f1(end:-1:1);
data2=data1*0;
data2(:,1:end)=data1(:,end:-1:1);
figure('color','wh');
pcolor(r0,f0,data2'); 
colormap(flipud(jet))
shading interp;
colorbar
caxis([180 270]);
% set(gca,'yDir','reverse');
set(gca,'xaxislocation','top');
c1=colorbar;
c1.Label.String='Phase velocity(m/s)';
set(c1,'fontsize',25);
ylabel('Frequency(Hz)','fontsize',25);
xlabel('Distance(m)','fontsize',25);
set(gca,'fontsize',25 ,'FontWeight','normal');
axis([min(r0) max(r0) 60 140 ])



r0=r;
clear f data;
f=f1;
data=data1;

% parameters for plotting
r0=[nr-1:-1:0]*0.5;
dr=0.05;
dp=0.1;
d=[0:dp:5];

%% harmonic average inversion method 
%  input
%           symbol:1=Rayleigh ;2=Love
%        data(r,f):frequency profile(2 dim)
%                f:frequency(Hz)(lowest->highest)
%               nr:the numbers of traces
%
%  output
%
%          dep(r,d):depth for each frequency (2 dim)
%          dis(r,v):velocity for each depth (2 dim)
symbol=1;
[Rdepth,Rdis]=arithmatic_inversion(symbol,data,nr,f);

%% figure 

for k=1:nr
    for tem=1:length(f)
        tp=(k-1)*length(f)+tem;
      x(tp)=r0(k);
      y(tp)=Rdepth(k,tem);
      z(tp)=Rdis(k,tem);
    end
end


[X,Y]=meshgrid(r0(end):dr:r0(1),d(1):dp:d(end));
Z=griddata(x,y,z,X,Y,'v4');

% smooth 
[t1,t2]=size(Z);
Z=smooth(Z,0.0009,'moving');
Z=reshape(Z,t1,t2);


figure('color','wh')
surf(X,Y,Z);
shading interp;
colorbar
colormap(flipud(jet));
ylabel('Depth(m)','fontsize',30);
xlabel('Distance(m)','fontsize',30);
zlabel('Distance(m)','fontsize',30);
% axis equal;
axis([r0(end) r0(1) 0.5 1.8])
caxis([230 330])
view(0,90);
set(gca,'fontweight','normal','ydir','reverse','fontsize',25);
set(gca,'xaxislocation','top');
c=colorbar;
c.Label.String='Vs (m/s)';
set(c,'fontsize',30);
