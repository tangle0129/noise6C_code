main function: 

fj_tilter.m;                                                   a complete example including all subroutines
wavelet_transform_example.m;                    an example of wavelet transform 
FJ_transform_example.m;                            an example of FJ transform 
dispersioncurves_example.m;                      an example of theorerical dispersion curves 
fre_dep_example.m;                                    an example of from frequency to depth domain

subroutine: 
halfwave_harmonic.m; 
arithmatic_inversion.m
./code
fj_forward.m
fj_inverse.m
cwt.cmor.m
ray_love_theory.m
