%% 6-C frequency-bessel transformation filtering
% Le Tang (SUStech) 2021-03-08

%% read fd data
clc; clear all; close all;
 
finename1='vx_shot1.bin';
finename2='vy_shot1.bin';
finename3='vz_shot1.bin';
finename4='vsx_shot1.bin';
finename5='vsy_shot1.bin';
finename6='vsz_shot1.bin';

[vx,dt,nt,nr,rec2]=readbindata(finename1);

[vy,dt,nt,nr,rec2]=readbindata(finename2);

[vz,dt,nt,nr,rec2]=readbindata(finename3);

[wx,dt,nt,nr,rec2]=readbindata(finename4);

[wy,dt,nt,nr,rec2]=readbindata(finename5);

[wz,dt,nt,nr2,rec2]=readbindata(finename6);


for i=1:nt-1
vx(i,:)=(vx(i+1,:)-vx(i,:))/dt;
vy(i,:)=(vy(i+1,:)-vy(i,:))/dt;
vz(i,:)=(vz(i+1,:)-vz(i,:))/dt;
end


gx=rec2(:,1);
gy=rec2(:,2);
gz=rec2(:,3);
t=[0:nt-1]*dt;

sx=-5;
sy=0;

r=sqrt((gx-sx).^2+(gy-sy).^2);
%% select the trace
n00=1;                        % the frist trace
n0=nr;                        % the last trace
dn=1;                         % interval of channel
dr=0.5;                         % interval of trace (m)
offset=2;                    % smallest offset (m)

data=vz(:,n00:dn:n0);         % vertical comp
data1=wy(:,n00:dn:n0);        % tangential comp
data2=wx(:,n00:dn:n0);        % tangential comp

figure('color','wh');
hold on;
agc=10^4;
for i=1:nr
    plot(t,i+data(:,i)*agc,'k-','linewidth',1.5);
end


nr=length(n00:dn:n0);         % the number of tracce

%% F-J transform
df=1/(dt)/nt;                 % frequency interval (unit:Hz)                                
fmin=df;                       
fmax=1/dt;
f=fmin:df:fmax;

% f-v domain
vs=[150 750];                 % the range of scanning velocity (unit:m/s)
dvs=1;                        % scanning velocity interval   (unit:m/s)
v=vs(1):dvs:vs(2);
% f-k domain
kn=[0.01 0.8];%pi/dr              % the range of scanning wavenumber 
dk=0.005;                     % scanning wavenumber interval   
k=kn(1):dk:kn(2);

agc=3;                        % energy gain (recommend:agc=2~5)

%% fj forward transformation
%  input:
%            f: scanning frequency(HZ) 1 dim
%         data: green function 2 dim :data(nt,nr) 
%            r: interstation (unit:m) 
%           nt: time samping points
%           nr: numbers of stations
%       symbol: 1= fk domain; 2= fv domain
%      k(or v): 1= fk domain:scanning wavenumber(HZ*s/m) ;2= fv domain:scanning velocity(m/s) 
%           dt: time interval (unit:s)
%          b_h:1=hankel function; 2=bessel function
% bessel_order:order of bessel(hankel) function
%
%  output:
%          E1: fk spectrum of f-v or f-k domain (2 dim)

cd ./code

symbol=2;
b_h=1;
bessel_order=0;

Ez=fj_forward(f,v,data,r,nt,nr,symbol,dt,b_h,bessel_order);
Ey=fj_forward(f,v,data1,r,nt,nr,symbol,dt,b_h,bessel_order);
Ex=fj_forward(f,v,data2,r,nt,nr,symbol,dt,b_h,bessel_order);


%filtering
for i=1:18
    st1=cursor_info(i).Position(1);
    st2=cursor_info(i).Position(2);
    
    Ez(st1:end,st2:end)=0;
    Ey(st1:end,st2:end)=0;
    Ex(st1:end,st2:end)=0;

end
%    st1=60;
%     Ez(1:end,1:st1)=0;
%     Ey(1:end,1:st1)=0;
%     Ex(1:end,1:st1)=0;
%   st1=10;
%     Ez(1:st1,1:end)=0;
%     Ey(1:st1,1:end)=0;
%     Ex(1:st1,1:end)=0; 
    
    



%%
agc=1;
temp=Ez;
for j=1:length(f)
   temp(j,:)=(abs(temp(j,:))/(max(abs(temp(j,:))))).^(agc);
end
temp1=Ey;
for j=1:length(f)
   temp1(j,:)=(abs(temp1(j,:))/(max(abs(temp1(j,:))))).^(agc);
end
temp2=Ex;
for j=1:length(f)
   temp2(j,:)=(abs(temp2(j,:))/(max(abs(temp2(j,:))))).^(agc);
end
% plot the fk domain 
% figure('color','wh');
% pcolor(abs(temp(1:50,:))');
% % pcolor(f,k,abs(temp)');
% colorbar;
% colormap((jet));
% shading interp;
% set(gca,'fontsize',14,'FontWeight','normal');
% xlabel('Frequency(HZ)','fontsize',15);
% ylabel('Wavenumber','fontsize',15);
% axis([5 35 kn(1) 0.8]);
% text(0,0.85,'(b)','fontsize',18);


% plot the fv domain 

figure('color','wh');
 pcolor(abs(temp1(1:50,:))');
%   pcolor(f,v,abs(temp)');
colorbar;
colormap(jet);
shading interp;
set(gca,'fontsize',24,'FontWeight','normal');
xlabel('Frequency(Hz)','fontsize',25);
ylabel('Phase velocity(m/s)','fontsize',25);
set(gca,'xaxislocation','top');
%  axis([40 220 vs(1) vs(2)-50]);
% text(-0.5,620,'(a)','fontsize',18);


%% theoretical dispersion

% input:
%             cvp: P wave's velocity model (m/s)
%             cvs: S wave's velocity model (m/s)
%             dns: density of model (kg/m^3)
%             thk: the depth of each layer (m)
%              pn: the interval of scanning frequency (Hz)
%              bn: the interval of scanning velocity (m/s)
%           f_min: start frequency (Hz)
%           f_max: end frequency (Hz)
%       lr_symbol: 1=Rayleigh; 2=Love
%          Norder: chose the order of calculation dispersion curves (include:0->Noder)
% output:
%         figure:dispersion points  


cvp=[0.4,0.8]*1d3;
cvs=[0.15,0.85]*1d3;
dns=[1.9,2.5]*1e3;
thk=[1.4];
n=max(size(cvs));
pn=5;                       
bn=1;                       
Norder=2;                   
f_min=1;
f_max=150;
lr_symbol=1;

ray_love_theory(cvp,cvs,dns,thk,pn,bn,Norder,f_min,f_max,2);

%% fj inverse transformation
%  input:
%           f: scanning frequency(HZ) 1 dim
%        data: green function 2 dim :data(nt,nr) 
%           r: interstation (unit:m) 
%          nt: time samping points
%          nr: numbers of stations
%      symbol: 1= fk domain; 2= fv domain
%     k(or v): 1= fk domain:scanning wavenumber(HZ*s/m) ;2= fv domain:scanning velocity(m/s) 
%          dt: time interval (unit:s)
% bessel_order:order of bessel(hankel) function
%  output:
%          E1: frequency-spatial spectrum (2 dim)

bessel_order=0;
fdataz=fj_inverse(f,v,Ez,r,nt,nr,symbol,dt,bessel_order);
fdatay=fj_inverse(f,v,Ey,r,nt,nr,symbol,dt,bessel_order);
fdatax=fj_inverse(f,v,Ex,r,nt,nr,symbol,dt,bessel_order);


for i=1:length(r) 
dataz(:,i)=real(ifft(fdataz(:,i)));
datay(:,i)=real(ifft(fdatay(:,i)));
datax(:,i)=real(ifft(fdatax(:,i)));
end




agc=10^6/2;
t=[1:length(f)]*dt;
figure('color','wh');
for i=1:nr
    hold on;
    h1=plot(t,i+datay(:,i)*agc,'k-','linewidth',1.5);
    h2=plot(t,i+data1(:,i)*agc,'r-','linewidth',1.5);
    %plot(i-datahr(:,i)*agc,t,'b--');
end
ylabel('Receiver','fontsize',18);
xlabel('t(s)','fontsize',18);
% set(gca,'xaxislocation','top'); 
set(gca,'fontsize',18,'FontWeight','normal');
set(gca,'YDir','reverse');
%  text(-0.2,-15,'(c)','fontsize',28);
axis tight;
box on;




for re0=1:1:nr    
 
wy0=(datay(:,re0));
vz0=(dataz(:,re0));

sm=1.5;

fs=1/dt;

[paz,f0] = pmtm(vz0,sm,length(vz0),fs);
[pay,f0] = pmtm(wy0,sm,length(wy0),fs);

fc(re0,:)=sqrt(paz./(pay));
end


%%
% % %% 
% for Rec=1:nr  % receiver position
% 
% 
% az=dataz(:,Rec);
% wy=datay(:,Rec);
% wx=datax(:,Rec);
% 
% %%
% fmin=1;          % started frequency (unit:Hz)
% fmax=180;         % ended frequency (unit:Hz)
% df=1/dt/nt*1;      % frequency interval (unit:Hz)  
% fs=1/dt;         % frequency sampling
% if(fmin<(1/dt/nt))
%    fmin=fmin+1/dt/nt; 
% end
% fp=fmin:df:fmax;  
% wcf=1.5;         % wavelet centrel frequency (unit:Hz)(recommend: 1~3)
% 
% 
% az0=cwt_cmor(az,1,wcf,fp,fs);
% wy0=cwt_cmor(wy,1,wcf,fp,fs);
% wx0=cwt_cmor(wx,1,wcf,fp,fs);
% 
% 
% % FIGURE_timefre(az0,t,fp,2);
% 
% %% dispersion analysis waveform matching
% % figure('color','wh')
% for fre=1:1:length(fp)
% z=real(az0(fre,:).^2);
% w=real(wy0(fre,:).^2);
% 
% 
% % shift cross-correlation
% % 
% [a,z0]=shift_corr(z,w);
% z=z0;
% 
% zp=z(1:end-1);
% wp=w(1:end-1);
% 
% 
% % hold on;
% % plot(z,'k-');
% % plot(wp*50000,'r-');
% 
% %  c(Rec,fre)=abs(sqrt(sum(abs(wp.*zp))/sum(wp.^2)));
% % disc(re0,fre)=abs(sqrt((abs(wp.*zp))/(wp.^2)));
%  c(Rec,fre)=abs(sqrt((abs(wp.*zp))/(wp.^2)));
% end
% 
%  end

figure('color','wh')
hold on
for i=1:nr
 plot(f0,fc(i,:),'o-','markersize',6)
end
% ray_love_theory(cvp,cvs,dns,thk,pn,bn,1,f_min,f_max,1);
% legend('1','2','3','4','5','6','7','8','9','10')
axis([0 180  100 650])


% smooth


fmin=50;
fmax=110;
f_0=round(fmin/df);
f_1=round(fmax/df);
f=f0(f_0:f_1);


data=fc(1:nr,f_0:f_1);

for i=1:nr
temp=smooth(data(i,:),0.1,'moving');
data(i,:)=temp;
end


 figure('color','wh')
 hold on
for i=1:nr
 plot(f,data(i,:),'*-')
end
axis([0 180  100 600])
%%
r0=[0:length(r)-1]*0.5;
figure('color','wh');
pcolor(r0,f,data'); 
colormap(flipud(jet))
shading interp;
colorbar
axis([min(r0)-0.5 max(r0)+0.5 fmin fmax ])
% axis([7+0.5 max(r)+0.5 fmin fmax ])
caxis([100 600]);
set(gca,'yDir','reverse'); 
set(gca,'xaxislocation','top');
c1=colorbar;
c1.Label.String='Phase velocity(m/s)';
set(c1,'fontsize',18);
ylabel('Frequency(HZ)','fontsize',18);
xlabel('Distance(m)','fontsize',18);
set(gca,'fontsize',18 ,'FontWeight','normal');
axis tight;
%  save('./testinv3.mat','fc','df','data','r','f0');