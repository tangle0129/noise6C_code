% Author: Le Tang  
% Southern University of Science and Technology, China. 2021-11-05
% Email:tangle0129@gmail.com

%% wavelet transform
% example

dt=0.01;
nt=100;
t=[0:nt-1]*dt;
x=sin(2*pi*15*t)+sin(2*pi*30*t);

fmin=1;                % started frequency (unit:Hz)
fmax=40;               % ended frequency (unit:Hz)
df=1/dt/nt;            % frequency interval (unit:Hz)  
fs=1/dt;               % frequency sampling
fp=fmin:df:fmax;  
wcf=1.5;               % wavelet centrel frequency (unit:Hz)(recommend: 1~3)

cd ./code

w_x=cwt_cmor(x,1,wcf,fp,fs);


figure(1)
pcolor(t,fp,abs(w_x));
colorbar;
shading interp;
ylabel('Frequency(Hz)','fontsize',12);
xlabel('Time','fontsize',12);


