% Author: Le Tang  
% Southern University of Science and Technology, China. 2021-11-05
% Email:tangle0129@gmail.com
function [E1]=fj_forward(f,k,data,r,nt,nr,symbol,dt,b_h,bessel_order)
%% fj forward transformation
%  input:
%           f: scanning frequency(HZ) 1 dim
%        data: green function 2 dim :data(nt,nr) 
%           r: interstation (unit:m) 
%          nt: time samping points
%          nr: numbers of stations
%      symbol: 1= fk domain; 2= fv domain
%     k(or v): 1= fk domain:scanning wavenumber(HZ*s/m) ;2= fv domain:scanning velocity(m/s) 
%          dt: time interval (unit:s)
%         b_h:1=hankel function; 2=bessel function
%        bessel_order:order of bessel(hankel) function
%  output:
%          E1: fk spectrum of f-v or f-k domain (2 dim)
tic

%% fk domain
if symbol==1
   
df=1/dt/nt;
E1=zeros(length(f),length(k));  % scanning engery for fj method

fftd=data*0;                    % data fft for fj method

for i=1:nr
 fftd(:,i)=fft(data(:,i));
end

% frequency and velocity scanning
for j=1:length(f)
    
    f(j)=f(j)-df;
    
        
    for i=1:length(k)
    
             E1(j,i)=(2*pi*f(j))^2*(intGj0(fftd(j,:),r,k(i),b_h,bessel_order) );

    end

end

    
end
%% fv domain
if symbol==2
    
v=k;   
    
df=1/dt/nt;
E1=zeros(length(f),length(v));  % scanning engery for fj method

fftd=data*0;                    % data fft for fj method


for i=1:nr
 fftd(:,i)=fft(data(:,i));
 
end

% frequency and velocity scanning
for j=1:length(f)
    
    f(j)=f(j)-df;
    
    for i=1:length(v)
         
         E1(j,i)=(2*pi*f(j))^2*(intGj0(fftd(j,:),r,2*pi*f(j)/v(i),b_h,bessel_order));

    end

   
end

end

E1(round(length(f)/2.):length(f),:)=0.0;


    toc
end

function I=intGj0(G,r,k,b_h,bessel_order)
%% fj integration;
%       input   G(r): is the green function 
%                 r : is the horizontal diatance(m)
%                 k : is the wavemumber
%                b_h:1=hankel function; 2=bessel function
%       bessel_order:order of bessel(hankel) function
%       output    I : integation for each k over all green function

n=length(G);
I=0;


if b_h==1
%% hankel function

% Trapezoidal integral by Le Tang 2021-11-5
s=0;
for i=1:n-1
    temp1=(r(i+1)-r(i))/2*(G(i+1)*besselh(bessel_order,1,k*r(i+1))*r(i+1)+G(i)*besselh(bessel_order,1,k*r(i))*r(i));    
    s=s+temp1;
    
end
I=s;

% simpson integration by Tang Le 2020-12-9
% note!!!(it need to update the distance interval for using the integration)

% h=(r(n)-r(1))/(n-1);
% s=(G(1)*besselh(0,1,k*r(1))*r(1)+G(n)*besselh(0,1,k*r(n))*r(n))*h/3;
% 
% for i=1:2:n-3
%     temp1=G(i+1)*besselh(0,1,k*r(i+1))*r(i+1);
%     temp2=G(i+2)*besselh(0,1,k*r(i+2))*r(i+2);
%     
%     s=s+4/3*h*temp1+2/3*h*temp2;
%     
% end
% s=s+4/3*h*G(n-1)*besselh(0,1,k*r(n-1))*r(n-1);
% 
% I=s;


else
%% bessel function
% Trapezoidal integral by Le Tang 2021-11-5    
s=0;
for i=1:n-1
    temp1=(r(i+1)-r(i))/2*(G(i+1)*besselj(bessel_order,k*r(i+1))*r(i+1)+G(i)*besselj(bessel_order,k*r(i))*r(i));    
    s=s+temp1;
    
end
I=s*2;


% simpson integration by Tang Le 2020-12-9
% note!!!(it need to update the distance interval for using the integration)
% h=(r(n)-r(1))/(n-1);
% s=(G(1)*besselj(0,k*r(1))*r(1)+G(n)*besselj(0,k*r(n))*r(n))*h/3;
% 
% for i=1:2:n-3
%     temp1=G(i+1)*besselj(0,k*r(i+1))*r(i+1);
%     temp2=G(i+2)*besselj(0,k*r(i+2))*r(i+2);
%     
%     s=s+4/3*h*temp1+2/3*h*temp2;
%     
% end
% s=s+4/3*h*G(n-1)*besselj(0,k*r(n-1))*r(n-1);
% I=s*2;



end









end       


