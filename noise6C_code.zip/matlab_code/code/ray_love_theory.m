% Author: Le Tang  
% Southern University of Science and Technology, China. 2021-11-05
% Email:tangle0129@gmail.com
function [f0,pha]=ray_love_theory(cvp,cvs,dns,thk,pn,bn,Norder,fmin,fmax,symbol)
%% calculate the theoretical dispersion curves using the fast delta method
% input:
%             cvp: P wave's velocity model (m/s)
%             cvs: S wave's velocity model (m/s)
%             dns: density of model (kg/m^3)
%             thk: the depth of each layer (m)
%              pn: the interval of scanning frequency (Hz)
%              bn: the interval of scanning velocity (m/s)
%           f_min: start frequency (Hz)
%           f_max: end frequency (Hz)
%       lr_symbol: 1=Rayleigh; 2=Love
%          Norder: chose the order of calculation dispersion curves (include:0->Noder)
% output:
%         figure:dispersion points  

%% theoretical Rayleigh dispersion curve
if symbol==1
ctmin=min(cvs)-50;
ctmax=max(cvs)+100;

i=1;
num=0;
for f=fmin:pn:fmax
    for ct=ctmin:bn:ctmax
        a=feval('Fast_Delta',ct,f,thk,dns,cvp,cvs);
        b=feval('Fast_Delta',ct+bn,f,thk,dns,cvp,cvs);
        if a*b<0
            ct1(round(f/pn)+1,i)=erfen('Fast_Delta',ct,ct+bn,f,thk,dns,cvp,cvs);
            if(ct1(floor(f/pn)+1,i)<= (max(cvs)+0))
                 hold on
                 hR=plot(f+pn/2,ct1(round(f/pn)+1,i),'o','MarkerEdgeColor','r','MarkerFaceColor','r','MarkerSize',5.0);              
                  num=num+1;
                  pha(num)=ct1(round(f/pn)+1,i); 
                  f0(num)=f+pn/2;
                 i=i+1;
            end
            if(i>Norder)
                break;
            end
            p=i-1;
        end
    end
    i=1;
end
end
set(gca,'fontsize',20,'FontWeight','normal');
xlabel('Frequency(Hz)','fontsize',20);
ylabel('Phase velocity(m/s)','fontsize',20);
box on;
grid on;

%% theoretical love dispersion curve
if symbol==2
hb=cvs;% vs

md=dns;% density
h=thk; % thick

n=max(size(hb)); 

ctmin=min(hb)-50;%
ctmax=max(hb)+100;%

i=1;

hold on
for f=fmin:pn:fmax
    for ct=ctmin:bn:ctmax
        a=feval('lovedispersion',ct+0.1,f,h,md,hb);
        b=feval('lovedispersion',ct+bn+0.1,f,h,md,hb);
        if a*b<0%--------------------------
            ct1(floor(f/pn)+1,i)=loveerfen('lovedispersion',ct+0.1,ct+bn+0.1,f,h,md,hb);
            if(ct1(floor(f/pn)+1,i)<= max(hb))
            hold on  
            plot(f,ct1(floor(f/pn)+1,i),'o','MarkerEdgeColor','r','MarkerFaceColor','r','MarkerSize',5);
            i=i+1;
            end
            if(i>Norder)
                break;
            end
%             p=i-1;
        end
    end
    i=1;
end



end
set(gca,'fontsize',20,'FontWeight','normal');
xlabel('Frequency(Hz)','fontsize',20);
ylabel('Phase velocity(m/s)','fontsize',20);
box on;
grid on;
end


function dd = Fast_Delta(vr,freq,thk,dns,cvp,cvs)

%  2011.4 by Kai

% Check to see if the trial phase velocity is equal to the shear wave velocity
% or compression wave velocity of one of the layers
% epsilon = 0.0001;
% while any(abs(om/k-cvs)<epsilon) || any(abs(om/k-cvp)<epsilon)
%    k = k * (1+epsilon);
% end   

n=max(size(cvs)); %n
om =2*pi*freq;
k = om/vr;
    
   cvs2 = cvs.^2; cvp2 = cvp.^2;
   mu = dns.*cvs2;

   k2 = k^2; om2 = om^2;
   p = k/om;
   p2 = p^2;
   r1 = cvs2./((om/k)^2);
   for j=1:n-1
       r_si(j) = dns(j+1)/dns(j);
       r_en(j) = 2*(r1(j)-r_si(j)*r1(j+1));
       
       r_a(j) = r_si(j) + r_en(j);
       r_a1(j) = r_a(j) - 1;
       r_b(j) = 1-r_en(j);
       r_b1(j) = r_b(j) - 1;
   end

   

   rk = sqrt(1-(om/k)^2./cvp2);
   sk = sqrt(1-(om/k)^2./cvs2);
   tk = 2-(om/k)^2./cvs2;
for i=1:n-1
   Ca(i) = cosh(k*rk(i)*thk(i));
   Sa(i) = sinh(k*rk(i)*thk(i));
   Cb(i) = cosh(k*sk(i)*thk(i));
   Sb(i) = sinh(k*sk(i)*thk(i));
end  
   X = mu(1)^2*[2*tk(1),-tk(1)^2,0,0,-4,2*tk(1)];
   
   for i=1:n-1
       pp1 = Cb(i)*X(2)+sk(i)*Sb(i)*X(3);
       pp2 = Cb(i)*X(4)+sk(i)*Sb(i)*X(5);
       pp3 = (1/sk(i))*Sb(i)*X(2)+Cb(i)*X(3);
       pp4 = (1/sk(i))*Sb(i)*X(4)+Cb(i)*X(5);
       
       qq1 = Ca(i)*pp1-rk(i)*Sa(i)*pp2;
       qq2 = -(1/rk(i))*Sa(i)*pp3+Ca(i)*pp4;
       qq3 = Ca(i)*pp3-rk(i)*Sa(i)*pp4;
       qq4 = -(1/rk(i))*Sa(i)*pp1+Ca(i)*pp2;
       
       yy1 = r_a1(i)*X(1)+r_a(i)*qq1;
       yy2 = r_a(i)*X(1)+r_a1(i)*qq2;
       
       zz1 = r_b(i)*X(1)+r_b1(i)*qq1;
       zz2 = r_b1(i)*X(1)+r_b(i)*qq2;
       
       X_new(1) = r_b1(i)*yy1+r_b(i)*yy2;
       X_new(2) = r_a(i)*yy1+r_a1(i)*yy2;
       X_new(3) = r_si(i)*qq3;
       X_new(4) = r_si(i)*qq4;
       X_new(5) = r_b1(i)*zz1+r_b(i)*zz2;
       X_new(6) = X_new(1);
       
       X = X_new;
   end
%        dd = real(X(2) + sk(end)*X(3) - rk(end)*(X(4)+sk(end)*X(5)));  
       dd = (X(2) + sk(end)*X(3) - rk(end)*(X(4)+sk(end)*X(5)));  
%        dd = dd/(abs(sum(X))+100);
end


function c=erfen(fun,a,b,t,h,d,vp,vs)

delta=0.0001;
ya=feval(fun,a,t,h,d,vp,vs);
yb=feval(fun,b,t,h,d,vp,vs);
max1=1+round((log(b-a)-log(delta))/log(2));% max1
for k=1:max1
    c=(b+a)/2;
    yc=feval(fun,c,t,h,d,vp,vs);
    if yc==0 
        a=c;
        b=c;
elseif yb*yc>0
        b=c;
        yb=yc;
    else a=c;
        ya=yc;
    end
    if b-a<delta break,end
end
c=(b+a)/2;
end

function y=lovedispersion(x,f,h,den,Vs)
n=length(den);
k=2*pi*f/x;%kΪ����
for i=1:n
    if(x<Vs(i))
        rs(i)=sqrt(1-x^2/Vs(i)^2);
    else
        rs(i)=conj(sqrt(1-x^2/Vs(i)^2));
    end
    t(i)=2-x^2/(Vs(i)^2);
    uu(i)=den(i)*(Vs(i)/1000)^2;
end
X=[0 1];
V=[1;
    uu(n)*rs(n)];
for i=1:n-1
    M=[1 0;
        0 uu(i)];
    E=[exp(k*rs(i)*h(i)) 0;
        0 exp(-k*rs(i)*h(i))];
    P=[1 1 ;
        rs(i) -rs(i)];
    Q=M*P;
    T=Q*E*Q^(-1);
    X=X*T;
end
y=det(X*V);
end

function c=loveerfen(fun,a,b,t,h,d,vs)

delta=0.0001;
ya=feval(fun,a,t,h,d,vs);
yb=feval(fun,b,t,h,d,vs);
max1=1+round((log(b-a)-log(delta))/log(2));% max1
for k=1:max1
    c=(b+a)/2;
    yc=feval(fun,c,t,h,d,vs);
    if yc==0 
        a=c;
        b=c;
elseif yb*yc>0
        b=c;
        yb=yc;
    else a=c;
        ya=yc;
    end
    if b-a<delta break,end
end
c=(b+a)/2;
end
