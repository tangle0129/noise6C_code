% Author: Le Tang  
% Southern University of Science and Technology, China. 2021-11-05
% Email:tangle0129@gmail.com
function [E1]=fj_inverse(f,k,data,r,nt,nr,symbol,dt,bessel_order)
%% fj inverse transformation
%  input:
%           f: scanning frequency(HZ) 1 dim
%        data: green function 2 dim :data(nt,nr) 
%           r: interstation (unit:m) 
%          nt: time samping points
%          nr: numbers of stations
%      symbol: 1= fk domain; 2= fv domain
%     k(or v): 1= fk domain:scanning wavenumber(HZ*s/m) ;2= fv domain:scanning velocity(m/s) 
%          dt: time interval (unit:s)
% bessel_order:order of bessel(hankel) function
%  output:
%          E1: frequency-spatial spectrum (2 dim)
tic

%% fk domain
if symbol==1
    
df=1/dt/nt;
E1=zeros(length(f),length(r));  % scanning engery for fj method


% frequency and velocity scanning
for j=1:length(f)
    
    f(j)=f(j)-df;
    
    for i=1:length(r)
 
     % F-J method (Wang et al. 2019,JGR Solid Earth)
         
     E1(j,i)=(intGj0_fk(data(j,:),k,r(i),2*pi*f(j),bessel_order));
    
    end
    
   
end

end
%% fv domain
if symbol==2
    
v=k;    
df=1/dt/nt;
E1=zeros(length(f),length(r));  % scanning engery for fj method

% frequency and velocity scanning
for j=1:length(f)
    
    f(j)=f(j)-df;
    
    for i=1:length(r)

     % F-J method (Wang et al. 2019,JGR Solid Earth)
         
     E1(j,i)=-(intGj0_fv(data(j,:),v,2*pi*f(j)*r(i),bessel_order));

    end

end

    
end


E1(1,:)=0.0;
    
    toc
end

function I=intGj0_fk(G,k,r,w,bessel_order)
%% fj integration;
%       input   G(r): is the green function 
%                 r : is the horizontal diatance(m)
%                 k : is the wavemumber
% bessel_order:order of bessel(hankel) function
%       output    I : integation for each k over all green function

n=length(G);
I=0;
%% simpson integration by Le Tang 2020-12-9

% h=(k(n)-k(1))/(n-1);
% s=(G(1)*besselj(bessel_order,k(1)*r)*(k(1)/w^2)+G(n)*besselj(bessel_order,k(n)*r)*(k(n)/w^2))*h/3;
% 
% for i=1:2:n-3
%     temp1=G(i+1)*besselj(bessel_order,k(i+1)*r)*(k(i+1)/w^2);
%     temp2=G(i+2)*besselj(bessel_order,k(i+2)*r)*(k(i+2)/w^2);
%     
%     s=s+4/3*h*temp1+2/3*h*temp2;
%     
% end
% s=s+4/3*h*G(n-1)*besselj(bessel_order,k(n-1)*r)*(k(n-1)/w^2);
% 
% I=s;

%% Trapezoidal integral by Le Tang 2021-11-5

s=0;
for i=1:n-1
    temp1=(k(i+1)-k(i))/2*(G(i)*besselj(bessel_order,k(i)*r)*(k(i)/w^2)+G(i+1)*besselj(bessel_order,k(i+1)*r)*(k(i+1)/w^2));    
    
    s=s+temp1;
    
end
I=s;

end       

function I=intGj0_fv(G,v,wr,bessel_order)
%% fj integration;
%       input   G(r): is the green function 
%                 r : is the horizontal diatance(m)
%                 k : is the wavemumber
% bessel_order:order of bessel(hankel) function
%       output    I : integation for each k over all green function

n=length(G);
I=0;

%% simpson integration by Le Tang 2020-12-9

% h=(v(n)-v(1))/(n-1);
% s=(G(1)*besselj(bessel_order,wr/v(1))*(-1/v(1)^3)+G(n)*besselj(bessel_order,wr/v(n))*(-1/v(n)^3))*h/3;
% 
% for i=1:2:n-3
%     temp1=G(i+1)*besselj(bessel_order,wr/v(i+1))*(-1/v(i+1)^3);
%     temp2=G(i+2)*besselj(bessel_order,wr/v(i+2))*(-1/v(i+2)^3);
%     
%     s=s+4/3*h*temp1+2/3*h*temp2;
%     
% end
% s=s+4/3*h*G(n-1)*besselj(bessel_order,wr/v(n-1))*(-1/v(n-1)^3);
% 
% I=s;

%% Trapezoidal integral by Le Tang 2021-11-5
s=0;
for i=1:n-1
    temp1=(v(i+1)-v(i))/2*(G(i+1)*besselj(bessel_order,wr/v(i+1))*(-1/v(i+1)^3)+G(i)*besselj(bessel_order,wr/v(i))*(-1/v(i)^3));    
    s=s+temp1;
    
end
I=s;

end       


