%% theoretical dispersion

% input:
%             cvp: P wave's velocity model (m/s)
%             cvs: S wave's velocity model (m/s)
%             dns: density of model (kg/m^3)
%             thk: the depth of each layer (m)
%              pn: the interval of scanning frequency (Hz)
%              bn: the interval of scanning velocity (m/s)
%           f_min: start frequency (Hz)
%           f_max: end frequency (Hz)
%       lr_symbol: 1=Rayleigh; 2=Love
%          Norder: chose the order of calculation dispersion curves (include:0->Noder)
% output:
%         figure:dispersion points  


cvp=[0.4,0.8]*1d3;  
cvs=[0.15,0.85]*1d3; 
dns=[1.9,2.5]*1e3; 
thk=[1.4];         
n=max(size(cvs));
pn=0.5;                   
bn=1;                      
Norder=1;                
f_min=1;             
f_max=50;          
lr_symbol=1;

ray_love_theory(cvp,cvs,dns,thk,pn,bn,Norder,f_min,f_max,lr_symbol);