% Author: Le Tang  
% Southern University of Science and Technology, China. 2021-11-05
% Email:tangle0129@gmail.com
function [dep,dis]=arithmatic_inversion(symbol,data,nr,f)
%% arithmatic average method for fundamental mode dispersion curve 
%  input
%           symbol:1=Rayleigh ;2=Love
%        data(r,f):frequency profile(2 dim)
%                f:frequency(Hz)(lowest->highest)
%               nr:the numbers of traces
%
%  output
%
%          dep(r,d):depth for each frequency (2 dim)
%          dis(r,v):velocity for each depth (2 dim)

%%
if symbol==1
    ratio=0.92;
else
    ratio=0.98;
end

    
for r=1:nr
    
pha=data(r,:);
 
% velocity of each layer
% ldep_v
[ldep,ldep_v]=halfwave_arithmatic(f,pha,ratio);

for i=1:length(f)
    lfdep(i)=sum(ldep(1:i));
end

%% plot the methods 

% ldep_v2=[ldep_v(:),ldep_v(:)]';
% lfdep2=[[0;lfdep(1:end-1)],lfdep(:)]';
% figure(2)
% hold on;
% h1=plot(dep_v2(:),fdep2(:),'r-','LineWidth',3);
% h2=plot(ldep_v2(:),lfdep2(:),'b-','LineWidth',3);
% % h3=plot(vs2(:),bott2(:),'k-','LineWidth',3);
% set(gca,'fontweight','normal','ydir','reverse','fontsize',16);
% xlabel('vs (m/s)','fontsize',18);
% ylabel('depth(m)','fontsize',18);
% box on;grid on;
% set(gca,'xaxislocation','top');
dep(r,:)=lfdep(:);
dis(r,:)=ldep_v(:);
end


end

function [ldep,ldep_v]=halfwave_arithmatic(f,v,ratio)

% modified half-wavelength method by Tang Le (2020 11.25. Sustech)

% input     f: frequency(HZ) low->high
%           v: phase velocity (m/s) corresponding to frequency
%           ratio : V(Rayleigh=0.92/Love=0.98) to VS ratio
   

v=v(end:-1:1)/ratio;
f=f(end:-1:1);
% velocity of each layer
ldep_v=zeros(length(f),1);
% thick of each layer
ldep=zeros(length(f),1);


ldep(1)=v(1)/(2*f(1));
ldep_v(1)=v(1);

for i=2:length(f)
    ldep(i)=v(i)/(2*f(i))-sum(ldep(1:i-1));
    if (ldep(i)<=0)
        ldep(i)=0;
        ldep_v(i)=ldep_v(i-1);
    else
        ldep_v(i)=(v(i)*sum(ldep(1:i))-sum(ldep(1:i-1).*ldep_v(1:i-1)))/ldep(i);
        if ldep_v(i)<=0
            ldep_v(i)=ldep_v(i-1);
        end
    end
    
    
end


end