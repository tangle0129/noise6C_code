function [D,dt,NT,NR,R]=readbindata(filename)
% read FD data (2D & 3D)
% [D,dx,dt,NT,NR,R,nsrc,S]=ReadFDdata(DIR,filename)
%
% Input:
%    DIR - path of data, e.g. '/home/data'
%    filename - .bin file name, e.g. 'vx.bin'
%
% Output:
%    D - trace data NT by NR
%    dx - grid spacing (Unit: meter)
%    dt - time sampling (Unit: second)
%    NT - number of time step
%    NR - number of receiver
%    R - receiver coordinate (NR by dim matrix) (Unit: meter)
%    nsrc - number of source
%    S - source coordinate (nsrc by dim matrix) (Unit:meter)
% 
% Xinding Fang, MIT-ERL
% 2011-1-20
%------------------------------------------------------

fid=fopen(filename,'r');
d=fread(fid,inf,'float32');
fclose(fid); 

dt=d(1);
NT=d(2); 
NR=d(3);

if NR>0
   R=d(4:3*NR+3); R=reshape(R,3,NR)';  % NR by dim
else
   R=[];
end

D=d(3*NR+4:end);
if length(D)==NR*NT
   D=reshape(D,NR,NT)'; % NT by NR
else
   NT=floor(length(D)/NR);
   D=reshape(D(1:NR*NT),NR,NT)';
end
   
% fid=fopen('vx_shot_1.bin','wb');
% % for i=1:NR
% %     for j=1:NT
%         fwrite(fid,D,'float32');
% %     end
% % end
% fclose(fid);
end