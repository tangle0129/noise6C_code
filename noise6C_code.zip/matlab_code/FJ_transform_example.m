% Author: Le Tang  
% Southern University of Science and Technology, China. 2021-11-05
% Email:tangle0129@gmail.com

%% F-J forward and inverse transform
% example

clc; clear all; close all;
 
finename1='vx_shot1.bin';
finename2='vy_shot1.bin';
finename3='vz_shot1.bin';
finename4='vsx_shot1.bin';
finename5='vsy_shot1.bin';
finename6='vsz_shot1.bin';

[vx,dt,nt,nr,rec2]=readbindata(finename1);
[vy,dt,nt,nr,rec2]=readbindata(finename2);
[vz,dt,nt,nr,rec2]=readbindata(finename3);
[wx,dt,nt,nr,rec2]=readbindata(finename4);
[wy,dt,nt,nr,rec2]=readbindata(finename5);
[wz,dt,nt,nr2,rec2]=readbindata(finename6);




gx=rec2(:,1);
gy=rec2(:,2);
gz=rec2(:,3);
t=[0:nt-1]*dt;

sx=-5;
sy=0;
r=sqrt((gx-sx).^2+(gy-sy).^2);

%% select the trace
n00=1;                        % the frist trace
n0=nr;                        % the last trace
dn=1;                         % interval of channel

data=vz(:,n00:dn:n0);         % vertical comp
data1=wy(:,n00:dn:n0);        % tangential comp
data2=wx(:,n00:dn:n0);        
nr=length(n00:dn:n0);         % the number of trace

%% F-J transform parameters
df=1/(dt)/nt;                 % frequency interval (unit:Hz)                                
fmin=df;                       
fmax=1/dt;
f=fmin:df:fmax;

% f-v domain
vs=[150 750];                 % the range of scanning velocity (unit:m/s)
dvs=1;                        % scanning velocity interval   (unit:m/s)
v=vs(1):dvs:vs(2);
% f-k domain
kn=[0.01 0.8];%pi/dr              % the range of scanning wavenumber 
dk=0.005;                     % scanning wavenumber interval   
k=kn(1):dk:kn(2);

agc=3;                        % energy gain (recommend:agc=2~5)

%% fj forward transformation
%  input:
%            f: scanning frequency(HZ) 1 dim
%         data: green function 2 dim :data(nt,nr) 
%            r: interstation (unit:m) 
%           nt: time samping points
%           nr: numbers of stations
%       symbol: 1= fk domain; 2= fv domain
%      k(or v): 1= fk domain:scanning wavenumber(HZ*s/m) ;2= fv domain:scanning velocity(m/s) 
%           dt: time interval (unit:s)
%          b_h:1=hankel function; 2=bessel function
% bessel_order:order of bessel(hankel) function
%
%  output:
%          E1: fk spectrum of f-v or f-k domain (2 dim)

cd ./code

symbol=2;
b_h=1;
bessel_order=0;

Ez=fj_forward(f,v,data,r,nt,nr,symbol,dt,b_h,bessel_order);
% Ey=fj_forward(f,v,data1,r,nt,nr,symbol,dt,b_h,bessel_order);
% Ex=fj_forward(f,v,data2,r,nt,nr,symbol,dt,b_h,bessel_order);


%%
agc=1;
temp=Ez;
for j=1:length(f)
   temp(j,:)=(abs(temp(j,:))/(max(abs(temp(j,:))))).^(agc);
end
% temp1=Ey;
% for j=1:length(f)
%    temp1(j,:)=(abs(temp1(j,:))/(max(abs(temp1(j,:))))).^(agc);
% end
% temp2=Ex;
% for j=1:length(f)
%    temp2(j,:)=(abs(temp2(j,:))/(max(abs(temp2(j,:))))).^(agc);
% end


% plot the fv domain 
figure('color','wh');
pcolor(f,v,abs(temp)');
colorbar;
colormap(jet);
shading interp;
set(gca,'fontsize',24,'FontWeight','normal');
xlabel('Frequency(Hz)','fontsize',25);
ylabel('Phase velocity(m/s)','fontsize',25);
set(gca,'xaxislocation','top');
axis([40 220 vs(1) vs(2)-50]);


%% fj inverse transformation
%  input:
%           f: scanning frequency(HZ) 1 dim
%        data: green function 2 dim :data(nt,nr) 
%           r: interstation (unit:m) 
%          nt: time samping points
%          nr: numbers of stations
%      symbol: 1= fk domain; 2= fv domain
%     k(or v): 1= fk domain:scanning wavenumber(HZ*s/m) ;2= fv domain:scanning velocity(m/s) 
%          dt: time interval (unit:s)
% bessel_order:order of bessel(hankel) function
%  output:
%          E1: frequency-spatial spectrum (2 dim)


fdataz=fj_inverse(f,v,Ez,r,nt,nr,symbol,dt,bessel_order);
fdatay=fj_inverse(f,v,Ey,r,nt,nr,symbol,dt,bessel_order);
fdatax=fj_inverse(f,v,Ex,r,nt,nr,symbol,dt,bessel_order);


for i=1:length(r) 
dataz(:,i)=real(ifft(fdataz(:,i)));
datay(:,i)=real(ifft(fdatay(:,i)));
datax(:,i)=real(ifft(fdatax(:,i)));
end



agc=10^6;
t=[1:length(f)]*dt;
figure('color','wh');
for i=1:nr
    hold on;
    h1=plot(t,i+dataz(:,i)*agc,'k-','linewidth',1.5);
    h2=plot(t,i+data(:,i)*agc,'r-','linewidth',1.5);
   
end
ylabel('Receiver','fontsize',18);
xlabel('t(s)','fontsize',18);
set(gca,'fontsize',18,'FontWeight','normal');
set(gca,'YDir','reverse');
axis tight;
box on;
